/**
 * Staff Flow Onboarding Workflow Lambda Function
 * 
 * This Lambda function is triggered by Cognito post-confirmation.
 * It handles:
 * - Adding user to appropriate Cognito group based on role
 * - Creating employee record in database
 * - Sending welcome email via SES
 * - Creating onboarding tasks for HR
 * 
 * Layer: staffflow-dependencies (arn:aws:lambda:us-east-1:320915182958:layer:staffflow-dependencies:2)
 * Dependencies: @neondatabase/serverless, @aws-sdk/client-ses, @aws-sdk/client-cognito-identity-provider
 */

const { NeonQueryFunction } = require('@neondatabase/serverless');
const { SESClient, SendEmailCommand } = require('@aws-sdk/client-ses');
const { CognitoIdentityProviderClient, AdminAddUserToGroupCommand } = require('@aws-sdk/client-cognito-identity-provider');

// Environment variables
const DATABASE_URL = process.env.DATABASE_URL;
const SES_FROM_EMAIL = process.env.SES_FROM_EMAIL || 'noreply@optimyzebz.com';
const AWS_REGION = process.env.AWS_REGION || 'us-east-1';
const COGNITO_USER_POOL_ID = process.env.COGNITO_USER_POOL_ID;

// Initialize clients
const sql = new NeonQueryFunction(DATABASE_URL);
const sesClient = new SESClient({ region: AWS_REGION });
const cognitoClient = new CognitoIdentityProviderClient({ region: AWS_REGION });

/**
 * Add user to Cognito group based on role
 */
async function addUserToGroup(username, role) {
  const groupMap = {
    'owner': 'Owners',
    'hr_manager': 'HR_Managers',
    'payroll_manager': 'Payroll_Managers',
    'manager': 'Managers',
    'employee': 'Employees'
  };

  const groupName = groupMap[role] || 'Employees';

  try {
    const command = new AdminAddUserToGroupCommand({
      UserPoolId: COGNITO_USER_POOL_ID,
      Username: username,
      GroupName: groupName
    });
    
    await cognitoClient.send(command);
    console.log(`Added user ${username} to group ${groupName}`);
    return { success: true, groupName };
  } catch (error) {
    console.error('Error adding user to group:', error);
    return { success: false, error: error.message };
  }
}

/**
 * Create or update employee record
 */
async function createOrUpdateEmployee(user) {
  const { email, given_name, family_name, custom_org_id, sub } = user;
  
  // Check if employee already exists
  const existingEmployee = await sql`
    SELECT id FROM employees WHERE email = ${email}
  `;

  if (existingEmployee.length > 0) {
    console.log(`Employee already exists for email: ${email}`);
    return { employeeId: existingEmployee[0].id, isNew: false };
  }

  // Create new employee record
  // Note: For new owners, organization_id may be null initially
  const result = await sql`
    INSERT INTO employees (
      organization_id,
      employee_number,
      first_name,
      last_name,
      email,
      hire_date,
      employment_status,
      employment_type,
      created_at
    )
    VALUES (
      ${custom_org_id || null},
      (SELECT COALESCE(MAX(employee_number::int), 0) + 1 FROM employees WHERE organization_id = ${custom_org_id})::text,
      ${given_name},
      ${family_name},
      ${email},
      CURRENT_DATE,
      'active',
      'full_time',
      NOW()
    )
    RETURNING id
  `;

  return { employeeId: result[0]?.id, isNew: true };
}

/**
 * Create onboarding task for HR manager
 */
async function createOnboardingTask(employeeId, organizationId, userRole) {
  // Only create tasks for employees, not for owners or managers
  if (userRole !== 'employee') {
    console.log('Skipping onboarding task for non-employee role');
    return null;
  }

  // Find HR manager for the organization
  const hrManager = await sql`
    SELECT u.id 
    FROM users u 
    WHERE u.organization_id = ${organizationId} 
      AND u.role = 'hr_manager'
    LIMIT 1
  `;

  if (hrManager.length === 0) {
    console.log('No HR manager found for organization');
    return null;
  }

  // Create onboarding tasks
  const tasks = [
    { task_type: 'collect_emergency_contact', due_days: 7 },
    { task_type: 'collect_bank_details', due_days: 7 },
    { task_type: 'collect_id_documents', due_days: 14 },
    { task_type: 'review_employment_contract', due_days: 14 },
    { task_type: 'schedule_orientation', due_days: 3 }
  ];

  const createdTasks = [];
  for (const task of tasks) {
    const dueDate = new Date();
    dueDate.setDate(dueDate.getDate() + task.due_days);

    const result = await sql`
      INSERT INTO onboarding_tasks (
        employee_id,
        task_type,
        status,
        assigned_to,
        due_date,
        created_at
      )
      VALUES (
        ${employeeId},
        ${task.task_type},
        'pending',
        ${hrManager[0].id},
        ${dueDate.toISOString()},
        NOW()
      )
      RETURNING id
    `;
    createdTasks.push(result[0]?.id);
  }

  return createdTasks;
}

/**
 * Send welcome email
 */
async function sendWelcomeEmail(user, employeeId, organizationId, userRole) {
  const { email, given_name, family_name } = user;
  
  const roleContent = {
    'owner': `
      <li>Set up your organization profile and billing information</li>
      <li>Invite team members to join your organization</li>
      <li>Configure your organization's compliance settings</li>
    `,
    'hr_manager': `
      <li>Complete employee onboarding tasks assigned to you</li>
      <li>Review and manage employee records</li>
      <li>Set up departments and positions</li>
    `,
    'manager': `
      <li>Review your team member information</li>
      <li>Approve leave requests from your team</li>
      <li>Set up your team's schedule</li>
    `,
    'employee': `
      <li>Complete your profile with emergency contact information</li>
      <li>Set up your direct deposit for payroll</li>
      <li>Review and sign your employment documents</li>
    `
  };

  const htmlContent = `
    <html>
      <body style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: linear-gradient(135deg, #0066cc 0%, #004499 100%); padding: 30px; text-align: center;">
          <h1 style="color: white; margin: 0;">Welcome to Staff Flow!</h1>
        </div>
        
        <div style="padding: 30px; background: #f9f9f9;">
          <h2 style="color: #333;">Hello ${given_name}!</h2>
          
          <p style="color: #666; line-height: 1.6;">
            Welcome to Staff Flow HR Management System. We're excited to have you on board!
          </p>
          
          <h3 style="color: #333;">Your Next Steps:</h3>
          <ul style="color: #666; line-height: 1.8;">
            ${roleContent[userRole] || roleContent['employee']}
            <li>Log in to your dashboard to get started</li>
          </ul>
          
          <div style="margin-top: 30px; text-align: center;">
            <a href="https://staffflow.bz/login" 
               style="background: #0066cc; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; display: inline-block;">
              Log In to Staff Flow
            </a>
          </div>
          
          <p style="color: #999; font-size: 12px; margin-top: 30px;">
            If you have any questions, please contact your organization's HR manager or system administrator.
          </p>
        </div>
        
        <div style="background: #333; color: white; padding: 20px; text-align: center; font-size: 12px;">
          <p style="margin: 0;">© ${new Date().getFullYear()} Staff Flow HRM. All rights reserved.</p>
        </div>
      </body>
    </html>
  `;

  const command = new SendEmailCommand({
    Source: SES_FROM_EMAIL,
    Destination: {
      ToAddresses: [email]
    },
    Message: {
      Subject: {
        Data: `Welcome to Staff Flow! 🎉`
      },
      Body: {
        Html: {
          Data: htmlContent
        }
      }
    }
  });

  try {
    await sesClient.send(command);
    console.log(`Welcome email sent to ${email}`);
    return true;
  } catch (error) {
    console.error('Failed to send welcome email:', error);
    return false;
  }
}

/**
 * Main Lambda handler
 */
exports.handler = async (event) => {
  console.log('Onboarding Workflow Lambda invoked');
  console.log('Event:', JSON.stringify(event, null, 2));

  try {
    // Extract user data from Cognito event
    const { userName, request, response } = event;
    const userAttributes = request?.userAttributes;
    
    if (!userAttributes) {
      console.error('No user attributes in event');
      return event; // Return unchanged
    }

    const user = {
      sub: userName,
      email: userAttributes.email,
      given_name: userAttributes.given_name || userAttributes.name?.split(' ')[0] || 'User',
      family_name: userAttributes.family_name || userAttributes.name?.split(' ').slice(1).join(' ') || '',
      custom_role: userAttributes['custom:role'] || 'employee',
      custom_org_id: userAttributes['custom:org_id']
    };

    console.log('Processing user:', user.email, 'with role:', user.custom_role);

    // Step 1: Add user to Cognito group
    const groupResult = await addUserToGroup(user.sub, user.custom_role);
    if (!groupResult.success) {
      console.error('Failed to add user to group:', groupResult.error);
    }

    // Step 2: Create employee record (if not owner or if org_id exists)
    let employeeResult = null;
    if (user.custom_role === 'owner' && !user.custom_org_id) {
      console.log('New owner - skipping employee record creation until org is set up');
    } else {
      employeeResult = await createOrUpdateEmployee(user);
      console.log('Employee record:', employeeResult);
    }

    // Step 3: Create onboarding tasks (only for employees with org)
    if (employeeResult && employeeResult.employeeId && user.custom_org_id) {
      await createOnboardingTask(employeeResult.employeeId, user.custom_org_id, user.custom_role);
    }

    // Step 4: Send welcome email
    await sendWelcomeEmail(user, employeeResult?.employeeId, user.custom_org_id, user.custom_role);

    console.log('Onboarding workflow completed successfully');
    
    return event;

  } catch (error) {
    console.error('Error in onboarding workflow:', error);
    // Don't throw - Cognito needs the event returned
    return event;
  }
};
