/**
 * Shared email utilities using AWS SES
 */

const AWS = require('aws-sdk');

const sesClient = new AWS.SES({
  region: process.env.AWS_REGION || 'us-east-1',
  apiVersion: '2010-12-01'
});

const fromEmail = process.env.SES_FROM_EMAIL || 'noreply@staffflow.hr';

/**
 * Send an email using SES
 * @param {string} to - Recipient email address
 * @param {string} subject - Email subject
 * @param {string} body - Email body (HTML or plain text)
 * @param {boolean} isHtml - Whether body is HTML
 */
async function sendEmail(to, subject, body, isHtml = true) {
  const params = {
    Destination: {
      ToAddresses: [to]
    },
    Message: {
      Body: isHtml ? {
        Html: {
          Charset: 'UTF-8',
          Data: body
        }
      } : {
        Text: {
          Charset: 'UTF-8',
          Data: body
        }
      },
      Subject: {
        Charset: 'UTF-8',
        Data: subject
      }
    },
    Source: fromEmail
  };

  try {
    const result = await sesClient.sendEmail(params).promise();
    console.log(`Email sent successfully to ${to}:`, result.MessageId);
    return {
      success: true,
      messageId: result.MessageId
    };
  } catch (error) {
    console.error(`Failed to send email to ${to}:`, error);
    throw error;
  }
}

/**
 * Send bulk emails (up to 50 recipients per call)
 * @param {Array<{to: string, subject: string, body: string, isHtml?: boolean}>} emails
 */
async function sendBulkEmails(emails) {
  const results = [];
  
  // SES has a limit of 50 destinations per sendEmail call
  const batchSize = 50;
  
  for (let i = 0; i < emails.length; i += batchSize) {
    const batch = emails.slice(i, i + batchSize);
    
    const params = {
      Destinations: batch.map(e => e.to),
      Source: fromEmail,
      Message: {
        // Note: This sends the same email to all recipients
        // For personalized emails, use sendEmail in a loop
        Body: {
          Html: {
            Charset: 'UTF-8',
            Data: batch[0].body
          }
        },
        Subject: {
          Charset: 'UTF-8',
          Data: batch[0].subject
        }
      }
    };

    try {
      const result = await sesClient.sendBulkTemplatedEmail(params).promise();
      results.push(...batch.map((e, idx) => ({
        to: e.to,
        status: result.Status[idx].Status === 'Success' ? 'success' : 'failed',
        error: result.Status[idx].Error
      })));
    } catch (error) {
      console.error('Failed to send bulk emails:', error);
      // Mark all as failed
      results.push(...batch.map(e => ({
        to: e.to,
        status: 'failed',
        error: error.message
      })));
    }
  }
  
  return results;
}

/**
 * Send a template-based email
 * @param {string} to - Recipient email
 * @param {string} templateName - SES template name
 * @param {object} templateData - Template data object
 */
async function sendTemplateEmail(to, templateName, templateData) {
  const params = {
    Destination: {
      ToAddresses: [to]
    },
    Source: fromEmail,
    Template: templateName,
    TemplateData: JSON.stringify(templateData)
  };

  try {
    const result = await sesClient.sendTemplatedEmail(params).promise();
    return {
      success: true,
      messageId: result.MessageId
    };
  } catch (error) {
    console.error(`Failed to send template email to ${to}:`, error);
    throw error;
  }
}

module.exports = {
  sendEmail,
  sendBulkEmails,
  sendTemplateEmail,
  fromEmail
};
