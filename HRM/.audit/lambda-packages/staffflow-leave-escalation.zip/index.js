/**
 * Staff Flow Leave Escalation Handler Lambda Function
 * 
 * This Lambda function is triggered by EventBridge daily to:
 * - Check for pending leave requests older than threshold days
 * - Send reminder emails to managers
 * - Escalate to HR if still pending
 * 
 * Layer: staffflow-dependencies (arn:aws:lambda:us-east-1:320915182958:layer:staffflow-dependencies:2)
 * Dependencies: @neondatabase/serverless, @aws-sdk/client-ses
 */

const { NeonQueryFunction } = require('@neondatabase/serverless');
const { SESClient, SendEmailCommand } = require('@aws-sdk/client-ses');

// Environment variables
const DATABASE_URL = process.env.DATABASE_URL;
const SES_FROM_EMAIL = process.env.SES_FROM_EMAIL || 'noreply@optimyzebz.com';
const AWS_REGION = process.env.AWS_REGION || 'us-east-1';
const PENDING_THRESHOLD_DAYS = parseInt(process.env.PENDING_THRESHOLD_DAYS || '3');

// Initialize clients
const sql = new NeonQueryFunction(DATABASE_URL);
const sesClient = new SESClient({ region: AWS_REGION });

/**
 * Get pending leave requests older than threshold
 */
async function getStalePendingRequests() {
  const thresholdDate = new Date();
  thresholdDate.setDate(thresholdDate.getDate() - PENDING_THRESHOLD_DAYS);
  
  const result = await sql`
    SELECT 
      lr.*,
      e.first_name as employee_first_name,
      e.last_name as employee_last_name,
      e.email as employee_email,
      m.first_name as manager_first_name,
      m.last_name as manager_last_name,
      m.email as manager_email,
      mu.id as manager_user_id
    FROM leave_requests lr
    JOIN employees e ON lr.employee_id = e.id
    LEFT JOIN employees m ON e.manager_id = m.id
    LEFT JOIN users mu ON m.id = mu.employee_id
    WHERE lr.status = 'pending'
      AND lr.created_at < ${thresholdDate.toISOString()}
    ORDER BY lr.created_at ASC
  `;
  
  return result;
}

/**
 * Get HR managers for escalation
 */
async function getHRManagers() {
  const result = await sql`
    SELECT DISTINCT
      e.first_name,
      e.last_name,
      e.email,
      u.id as user_id
    FROM users u
    JOIN employees e ON u.employee_id = e.id
    WHERE u.role = 'hr_manager'
      AND u.is_active = true
  `;
  return result;
}

/**
 * Send reminder email to manager
 */
async function sendReminderEmail(manager, leaveRequest, daysPending) {
  if (!manager?.email) {
    console.log('No manager email, skipping reminder');
    return false;
  }

  const htmlContent = `
    <html>
      <body style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: #fff3cd; padding: 20px;">
          <h2 style="color: #856404;">⏰ Leave Request Reminder</h2>
          
          <div style="background: white; padding: 20px; border-radius: 5px;">
            <p>Dear ${manager.first_name} ${manager.last_name},</p>
            
            <p>This is a reminder that the following leave request has been pending for <strong>${daysPending} days</strong>:</p>
            
            <table style="width: 100%; border-collapse: collapse;">
              <tr>
                <td style="padding: 8px; border: 1px solid #ddd;"><strong>Employee</strong></td>
                <td style="padding: 8px; border: 1px solid #ddd;">${leaveRequest.employee_first_name} ${leaveRequest.employee_last_name}</td>
              </tr>
              <tr>
                <td style="padding: 8px; border: 1px solid #ddd;"><strong>Leave Type</strong></td>
                <td style="padding: 8px; border: 1px solid #ddd;">${leaveRequest.leave_type}</td>
              </tr>
              <tr>
                <td style="padding: 8px; border: 1px solid #ddd;"><strong>Start Date</strong></td>
                <td style="padding: 8px; border: 1px solid #ddd;">${leaveRequest.start_date}</td>
              </tr>
              <tr>
                <td style="padding: 8px; border: 1px solid #ddd;"><strong>End Date</strong></td>
                <td style="padding: 8px; border: 1px solid #ddd;">${leaveRequest.end_date}</td>
              </tr>
              <tr>
                <td style="padding: 8px; border: 1px solid #ddd;"><strong>Days Pending</strong></td>
                <td style="padding: 8px; border: 1px solid #ddd;">${daysPending}</td>
              </tr>
            </table>
            
            <div style="margin-top: 20px;">
              <a href="https://staffflow.bz/dashboard/leave/review/${leaveRequest.id}" 
                 style="background: #0066cc; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; display: inline-block;">
                Review Now
              </a>
            </div>
          </div>
          
          <p style="color: #856404; font-size: 12px; margin-top: 10px;">
            Please review pending requests to ensure timely response to employees.
          </p>
        </div>
      </body>
    </html>
  `;

  const command = new SendEmailCommand({
    Source: SES_FROM_EMAIL,
    Destination: {
      ToAddresses: [manager.email]
    },
    Message: {
      Subject: {
        Data: `⏰ Reminder: Pending Leave Request from ${leaveRequest.employee_first_name} ${leaveRequest.employee_last_name}`
      },
      Body: {
        Html: {
          Data: htmlContent
        }
      }
    }
  });

  try {
    await sesClient.send(command);
    console.log(`Reminder sent to manager ${manager.email}`);
    return true;
  } catch (error) {
    console.error('Failed to send reminder:', error);
    return false;
  }
}

/**
 * Send escalation email to HR
 */
async function sendEscalationEmail(hrManager, staleRequests) {
  if (!hrManager?.email) {
    return false;
  }

  const requestList = staleRequests.map(r => 
    `<li>${r.employee_first_name} ${r.employee_last_name} - ${r.leave_type} (${r.start_date} to ${r.end_date}) - Pending ${Math.floor((Date.now() - new Date(r.created_at).getTime()) / (1000 * 60 * 60 * 24))} days</li>`
  ).join('');

  const htmlContent = `
    <html>
      <body style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: #dc3545; padding: 20px;">
          <h2 style="color: white;">⚠️ Escalation: Pending Leave Requests</h2>
          
          <div style="background: white; padding: 20px; border-radius: 5px;">
            <p>Dear ${hrManager.first_name} ${hrManager.last_name},</p>
            
            <p>The following leave requests have been pending for more than ${PENDING_THRESHOLD_DAYS} days and require attention:</p>
            
            <ul>
              ${requestList}
            </ul>
            
            <div style="margin-top: 20px;">
              <a href="https://staffflow.bz/dashboard/leave/pending-approvals" 
                 style="background: #dc3545; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; display: inline-block;">
                View Pending Requests
              </a>
            </div>
          </div>
        </div>
      </body>
    </html>
  `;

  const command = new SendEmailCommand({
    Source: SES_FROM_EMAIL,
    Destination: {
      ToAddresses: [hrManager.email]
    },
    Message: {
      Subject: {
        Data: `⚠️ Escalation: ${staleRequests.length} Leave Requests Need Immediate Attention`
      },
      Body: {
        Html: {
          Data: htmlContent
        }
      }
    }
  });

  try {
    await sesClient.send(command);
    console.log(`Escalation sent to HR ${hrManager.email}`);
    return true;
  } catch (error) {
    console.error('Failed to send escalation:', error);
    return false;
  }
}

/**
 * Main Lambda handler
 */
exports.handler = async (event) => {
  console.log('Leave Escalation Handler Lambda invoked');
  console.log('Pending threshold days:', PENDING_THRESHOLD_DAYS);

  try {
    // Get stale pending requests
    const staleRequests = await getStalePendingRequests();
    console.log(`Found ${staleRequests.length} stale pending requests`);

    if (staleRequests.length === 0) {
      return {
        statusCode: 200,
        body: JSON.stringify({
          message: 'No stale pending requests found',
          processed: 0
        })
      };
    }

    // Group requests by manager
    const requestsByManager = {};
    for (const request of staleRequests) {
      const managerId = request.manager_user_id || 'hr';
      if (!requestsByManager[managerId]) {
        requestsByManager[managerId] = {
          manager: {
            email: request.manager_email,
            first_name: request.manager_first_name,
            last_name: request.manager_last_name
          },
          requests: []
        };
      }
      requestsByManager[managerId].requests.push(request);
    }

    // Send reminders to managers
    let remindersSent = 0;
    for (const [managerId, data] of Object.entries(requestsByManager)) {
      if (data.manager.email) {
        for (const request of data.requests) {
          const daysPending = Math.floor(
            (Date.now() - new Date(request.created_at).getTime()) / (1000 * 60 * 60 * 24)
          );
          await sendReminderEmail(data.manager, request, daysPending);
          remindersSent++;
        }
      }
    }

    // Escalate to HR if there are any stale requests
    const hrManagers = await getHRManagers();
    let escalationsSent = 0;
    
    if (hrManagers.length > 0) {
      for (const hrManager of hrManagers) {
        await sendEscalationEmail(hrManager, staleRequests);
        escalationsSent++;
      }
    }

    console.log(`Processed ${staleRequests.length} stale requests: ${remindersSent} reminders, ${escalationsSent} escalations`);

    return {
      statusCode: 200,
      body: JSON.stringify({
        message: 'Escalation processing completed',
        staleRequestsCount: staleRequests.length,
        remindersSent,
        escalationsSent
      })
    };

  } catch (error) {
    console.error('Error in escalation handler:', error);
    
    return {
      statusCode: 500,
      body: JSON.stringify({ 
        error: error.message 
      })
    };
  }
};
